// Tetris implementācija
function initTetris(container, instructionsContainer, lang) {
    const canvas = document.createElement('canvas');
    canvas.width = 200;
    canvas.height = 300;
    container.appendChild(canvas);
    const ctx = canvas.getContext('2d');

    const gridSize = 20;
    const cols = canvas.width / gridSize;
    const rows = canvas.height / gridSize;
    let board = Array(rows).fill().map(() => Array(cols).fill(0));
    let piece = createPiece();
    let score = 0;

    function createPiece() {
        const pieces = [
            [[1, 1, 1, 1]], // I
            [[1, 1], [1, 1]], // O
            [[1, 1, 1], [0, 1, 0]], // T
            [[1, 1, 1], [1, 0, 0]], // L
            [[1, 1, 1], [0, 0, 1]], // J
            [[0, 1, 1], [1, 1, 0]], // S
            [[1, 1, 0], [0, 1, 1]] // Z
        ];
        const newPiece = pieces[Math.floor(Math.random() * pieces.length)];
        return { shape: newPiece, x: Math.floor(cols / 2) - 1, y: 0 };
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#000';
        
        // Draw board
        for (let y = 0; y < rows; y++) {
            for (let x = 0; x < cols; x++) {
                if (board[y][x]) {
                    ctx.fillRect(x * gridSize, y * gridSize, gridSize - 1, gridSize - 1);
                }
            }
        }

        // Draw current piece
        piece.shape.forEach((row, y) => {
            row.forEach((val, x) => {
                if (val) {
                    ctx.fillRect((x + piece.x) * gridSize, (y + piece.y) * gridSize, gridSize - 1, gridSize - 1);
                }
            });
        });

        // Draw score
        ctx.fillStyle = '#000';
        ctx.font = '16px Roboto';
        ctx.fillText(`${translations[lang].score}: ${score}`, 10, 20);
    }

    function movePiece(dx, dy) {
        piece.x += dx;
        piece.y += dy;
        if (collision()) {
            piece.x -= dx;
            piece.y -= dy;
            return false;
        }
        return true;
    }

    function rotatePiece() {
        const newShape = piece.shape[0].map((_, index) =>
            piece.shape.map(row => row[index]).reverse()
        );
        const oldShape = piece.shape;
        piece.shape = newShape;
        if (collision()) {
            piece.shape = oldShape;
        }
    }

    function collision() {
        return piece.shape.some((row, y) => 
            row.some((val, x) => {
                if (!val) return false;
                const newX = x + piece.x;
                const newY = y + piece.y;
                return newX < 0 || newX >= cols || newY >= rows || (newY >= 0 && board[newY][newX]);
            })
        );
    }

    function merge() {
        piece.shape.forEach((row, y) => {
            row.forEach((val, x) => {
                if (val) board[y + piece.y][x + piece.x] = 1;
            });
        });
        clearLines();
        piece = createPiece();
        if (collision()) {
            saveScore('tetris', score);
            board = Array(rows).fill().map(() => Array(cols).fill(0));
            score = 0;
        }
    }

    function clearLines() {
        for (let y = rows - 1; y >= 0; y--) {
            if (board[y].every(val => val)) {
                board.splice(y, 1);
                board.unshift(Array(cols).fill(0));
                score += 10;
            }
        }
    }

    const keyHandler = (e) => {
        if (e.key === 'ArrowLeft') movePiece(-1, 0);
        if (e.key === 'ArrowRight') movePiece(1, 0);
        if (e.key === 'ArrowDown') movePiece(0, 1) || merge();
        if (e.key === 'ArrowUp') rotatePiece();
        draw();
    };

    document.addEventListener('keydown', keyHandler);

    piece = createPiece();
    setInterval(() => {
        if (!movePiece(0, 1)) merge();
        draw();
    }, 500);

    draw();

    instructionsContainer.textContent = translations[lang].tetris_instructions;

    return () => document.removeEventListener('keydown', keyHandler);
}

// 2048 implementācija
function init2048(container, instructionsContainer, lang) {
    const wrapper = document.createElement('div');
    const board = document.createElement('div');
    board.style.display = 'grid';
    board.style.gridTemplateColumns = 'repeat(4, 50px)';
    board.style.gridGap = '5px';
    board.style.padding = '10px';
    board.style.background = '#bbada0';
    board.style.borderRadius = '5px';
    wrapper.appendChild(board);
    container.appendChild(wrapper);

    let tiles = Array(4).fill().map(() => Array(4).fill(0));
    let score = 0;

    function addTile() {
        let empty = [];
        for (let i = 0; i < 4; i++) {
            for (let j = 0; j < 4; j++) {
                if (tiles[i][j] === 0) empty.push({ x: i, y: j });
            }
        }
        if (empty.length) {
            const { x, y } = empty[Math.floor(Math.random() * empty.length)];
            tiles[x][y] = Math.random() < 0.9 ? 2 : 4;
        }
    }

    function draw() {
        board.innerHTML = '';
        for (let i = 0; i < 4; i++) {
            for (let j = 0; j < 4; j++) {
                const tile = document.createElement('div');
                tile.style.width = '50px';
                tile.style.height = '50px';
                tile.style.background = tiles[i][j] === 0 ? '#cdc1b4' : getTileColor(tiles[i][j]);
                tile.style.display = 'flex';
                tile.style.alignItems = 'center';
                tile.style.justifyContent = 'center';
                tile.style.fontSize = '20px';
                tile.style.color = tiles[i][j] <= 4 ? '#776e65' : '#f9f6f2';
                tile.style.borderRadius = '3px';
                tile.textContent = tiles[i][j] || '';
                board.appendChild(tile);
            }
        }

        let scoreDisplay = wrapper.querySelector('.score-display');
        if (!scoreDisplay) {
            scoreDisplay = document.createElement('div');
            scoreDisplay.className = 'score-display';
            scoreDisplay.style.marginTop = '10px';
            scoreDisplay.style.fontSize = '16px';
            wrapper.appendChild(scoreDisplay);
        }
        scoreDisplay.textContent = `${translations[lang].score}: ${score}`;
    }

    function getTileColor(value) {
        const colors = {
            2: '#eee4da',
            4: '#ede0c8',
            8: '#f2b179',
            16: '#f59563',
            32: '#f67c5f',
            64: '#f65e3b',
            128: '#edcf72',
            256: '#edcc61',
            512: '#edc850',
            1024: '#edc53f',
            2048: '#edc22e'
        };
        return colors[value] || '#cdc1b4';
    }

    function move(direction) {
        let moved = false;
        let newTiles = tiles.map(row => [...row]);

        if (direction === 'left' || direction === 'right') {
            for (let i = 0; i < 4; i++) {
                let row = newTiles[i].filter(val => val);
                if (direction === 'right') row.reverse();
                for (let j = 0; j < row.length - 1; j++) {
                    if (row[j] === row[j + 1]) {
                        row[j] *= 2;
                        score += row[j];
                        row[j + 1] = 0;
                        moved = true;
                    }
                }
                row = row.filter(val => val);
                while (row.length < 4) row.push(0);
                if (direction === 'right') row.reverse();
                newTiles[i] = row;
            }
        } else {
            for (let j = 0; j < 4; j++) {
                let col = [];
                for (let i = 0; i < 4; i++) {
                    if (newTiles[i][j]) col.push(newTiles[i][j]);
                }
                if (direction === 'down') col.reverse();
                for (let k = 0; k < col.length - 1; k++) {
                    if (col[k] === col[k + 1]) {
                        col[k] *= 2;
                        score += col[k];
                        col[k + 1] = 0;
                        moved = true;
                    }
                }
                col = col.filter(val => val);
                while (col.length < 4) col.push(0);
                if (direction === 'down') col.reverse();
                for (let i = 0; i < 4; i++) {
                    newTiles[i][j] = col[i];
                }
            }
        }

        if (JSON.stringify(tiles) !== JSON.stringify(newTiles)) {
            tiles = newTiles;
            addTile();
            moved = true;
        }

        if (moved) draw();
    }

    const keyHandler = (e) => {
        if (e.key === 'ArrowUp') move('up');
        if (e.key === 'ArrowDown') move('down');
        if (e.key === 'ArrowLeft') move('left');
        if (e.key === 'ArrowRight') move('right');
    };

    document.addEventListener('keydown', keyHandler);

    addTile();
    addTile();
    draw();

    instructionsContainer.textContent = translations[lang]["2048_instructions"];

    return () => {
        document.removeEventListener('keydown', keyHandler);
        saveScore('2048', score);
    };
}

// Minesweeper implementācija
function initMinesweeper(container, instructionsContainer, lang) {
    const board = document.createElement('div');
    board.style.display = 'grid';
    board.style.gridTemplateColumns = 'repeat(8, 30px)';
    board.style.gridGap = '1px';
    board.style.background = '#aaa';
    board.style.padding = '5px';
    container.appendChild(board);

    const size = 8;
    const mines = 10;
    let grid = Array(size).fill().map(() => Array(size).fill(0));
    let revealed = Array(size).fill().map(() => Array(size).fill(false));
    let score = 0;

    // Place mines
    for (let i = 0; i < mines; i++) {
        let x, y;
        do {
            x = Math.floor(Math.random() * size);
            y = Math.floor(Math.random() * size);
        } while (grid[x][y] === -1);
        grid[x][y] = -1;
    }

    // Calculate numbers
    for (let i = 0; i < size; i++) {
        for (let j = 0; j < size; j++) {
            if (grid[i][j] === -1) continue;
            let count = 0;
            for (let di = -1; di <= 1; di++) {
                for (let dj = -1; dj <= 1; dj++) {
                    if (di === 0 && dj === 0) continue;
                    const ni = i + di, nj = j + dj;
                    if (ni >= 0 && ni < size && nj >= 0 && nj < size && grid[ni][nj] === -1) count++;
                }
            }
            grid[i][j] = count;
        }
    }

    function reveal(x, y) {
        if (x < 0 || x >= size || y < 0 || y >= size || revealed[x][y]) return;
        revealed[x][y] = true;
        score += 1;
        if (grid[x][y] === 0) {
            for (let di = -1; di <= 1; di++) {
                for (let dj = -1; dj <= 1; dj++) {
                    reveal(x + di, y + dj);
                }
            }
        }
        draw();
    }

    function draw() {
        board.innerHTML = '';
        for (let i = 0; i < size; i++) {
            for (let j = 0; j < size; j++) {
                const cell = document.createElement('div');
                cell.style.width = '30px';
                cell.style.height = '30px';
                cell.style.background = revealed[i][j] ? '#ddd' : '#bbb';
                cell.style.display = 'flex';
                cell.style.alignItems = 'center';
                cell.style.justifyContent = 'center';
                cell.style.fontSize = '14px';
                cell.style.cursor = 'pointer';
                if (revealed[i][j]) {
                    cell.textContent = grid[i][j] === -1 ? '💣' : grid[i][j] || '';
                    cell.style.color = grid[i][j] === 1 ? 'blue' : grid[i][j] === 2 ? 'green' : 'red';
                }
                cell.addEventListener('click', () => {
                    if (grid[i][j] === -1) {
                        saveScore('minesweeper', score);
                        alert(translations[lang].minesweeper_game_over);
                        grid = Array(size).fill().map(() => Array(size).fill(0));
                        revealed = Array(size).fill().map(() => Array(size).fill(false));
                        score = 0;
                        // Place new mines
                        for (let m = 0; m < mines; m++) {
                            let x, y;
                            do {
                                x = Math.floor(Math.random() * size);
                                y = Math.floor(Math.random() * size);
                            } while (grid[x][y] === -1);
                            grid[x][y] = -1;
                        }
                        // Recalculate numbers
                        for (let i = 0; i < size; i++) {
                            for (let j = 0; j < size; j++) {
                                if (grid[i][j] === -1) continue;
                                let count = 0;
                                for (let di = -1; di <= 1; di++) {
                                    for (let dj = -1; dj <= 1; dj++) {
                                        if (di === 0 && dj === 0) continue;
                                        const ni = i + di, nj = j + dj;
                                        if (ni >= 0 && ni < size && nj >= 0 && nj < size && grid[ni][nj] === -1) count++;
                                    }
                                }
                                grid[i][j] = count;
                            }
                        }
                    } else {
                        reveal(i, j);
                    }
                });
                board.appendChild(cell);
            }
        }

        let scoreDisplay = container.querySelector('.score-display');
        if (!scoreDisplay) {
            scoreDisplay = document.createElement('div');
            scoreDisplay.className = 'score-display';
            scoreDisplay.style.marginTop = '10px';
            scoreDisplay.style.fontSize = '16px';
            container.appendChild(scoreDisplay);
        }
        scoreDisplay.textContent = `${translations[lang].score}: ${score}`;
    }

    draw();

    instructionsContainer.textContent = translations[lang].minesweeper_instructions;

    return () => saveScore('minesweeper', score);
}

// Memory implementācija
function initMemory(container, instructionsContainer, lang) {
    const board = document.createElement('div');
    board.style.display = 'grid';
    board.style.gridTemplateColumns = 'repeat(4, 50px)';
    board.style.gridGap = '5px';
    board.style.padding = '10px';
    container.appendChild(board);

    const size = 4;
    let cards = [];
    let values = ['A', 'A', 'B', 'B', 'C', 'C', 'D', 'D', 'E', 'E', 'F', 'F', 'G', 'G', 'H', 'H'];
    values.sort(() => Math.random() - 0.5);
    let flipped = [];
    let matched = [];
    let score = 0;

    function draw() {
        board.innerHTML = '';
        for (let i = 0; i < size * size; i++) {
            const card = document.createElement('div');
            card.style.width = '50px';
            card.style.height = '50px';
            card.style.background = matched.includes(i) || flipped.includes(i) ? '#ddd' : '#bbb';
            card.style.display = 'flex';
            card.style.alignItems = 'center';
            card.style.justifyContent = 'center';
            card.style.fontSize = '20px';
            card.style.cursor = 'pointer';
            card.textContent = matched.includes(i) || flipped.includes(i) ? values[i] : '';
            card.addEventListener('click', () => {
                if (flipped.length < 2 && !flipped.includes(i) && !matched.includes(i)) {
                    flipped.push(i);
                    if (flipped.length === 2) {
                        if (values[flipped[0]] === values[flipped[1]]) {
                            matched.push(...flipped);
                            score += 10;
                            if (matched.length === size * size) {
                                saveScore('memory', score);
                                alert(translations[lang].memory_win);
                                values.sort(() => Math.random() - 0.5);
                                flipped = [];
                                matched = [];
                                score = 0;
                            }
                        }
                        setTimeout(() => {
                            flipped = [];
                            draw();
                        }, 1000);
                    }
                    draw();
                }
            });
            board.appendChild(card);
        }

        let scoreDisplay = container.querySelector('.score-display');
        if (!scoreDisplay) {
            scoreDisplay = document.createElement('div');
            scoreDisplay.className = 'score-display';
            scoreDisplay.style.marginTop = '10px';
            scoreDisplay.style.fontSize = '16px';
            container.appendChild(scoreDisplay);
        }
        scoreDisplay.textContent = `${translations[lang].score}: ${score}`;
    }

    draw();

    instructionsContainer.textContent = translations[lang].memory_instructions;

    return () => saveScore('memory', score);
}

// Valodu tulkojumi
const translations = {
    en: {
        tetris: "Tetris",
        "2048": "2048",
        minesweeper: "Minesweeper",
        memory: "Memory",
        theme_light: "Light",
        theme_dark: "Dark",
        difficulty_easy: "Easy",
        difficulty_medium: "Medium",
        difficulty_hard: "Hard",
        timer: "5 min",
        scores: "Scores",
        score: "Score",
        tetris_instructions: "←/→: Move, ↓: Speed up, ↑: Rotate",
        "2048_instructions": "Arrows: Move tiles",
        minesweeper_instructions: "Click to reveal, avoid mines!",
        minesweeper_game_over: "Game Over! You hit a mine.",
        memory_instructions: "Click to flip cards, match pairs!",
        memory_win: "You won!",
        timer_alert: "5 minutes are up!"
    },
    lv: {
        tetris: "Tetris",
        "2048": "2048",
        minesweeper: "Mīnu meklētājs",
        memory: "Atmiņa",
        theme_light: "Gaišs",
        theme_dark: "Tumšs",
        difficulty_easy: "Viegli",
        difficulty_medium: "Vidēji",
        difficulty_hard: "Grūti",
        timer: "5 min",
        scores: "Rezultāti",
        score: "Punkti",
        tetris_instructions: "←/→: Pārvietot, ↓: Paātrināt, ↑: Pagriezt",
        "2048_instructions": "Bultiņas: Pārvietot flīzes",
        minesweeper_instructions: "Klikšķis, lai atklātu, izvairies no mīnām!",
        minesweeper_game_over: "Spēle beigusies! Jūs uzgājāt mīnu.",
        memory_instructions: "Klikšķis, lai apgrieztu kartes, meklē pārus!",
        memory_win: "Jūs uzvarējāt!",
        timer_alert: "5 minūtes ir beigušās!"
    },
    lt: {
        tetris: "Tetris",
        "2048": "2048",
        minesweeper: "Minų ieškotojas",
        memory: "Atmintis",
        theme_light: "Šviesus",
        theme_dark: "Tamsus",
        difficulty_easy: "Lengva",
        difficulty_medium: "Vidutinė",
        difficulty_hard: "Sunku",
        timer: "5 min",
        scores: "Rezultatai",
        score: "Taškai",
        tetris_instructions: "←/→: Judėti, ↓: Pagreitinti, ↑: Sukti",
        "2048_instructions": "Rodyklės: Stumti plyteles",
        minesweeper_instructions: "Spustelėkite, kad atskleistumėte, venkite minų!",
        minesweeper_game_over: "Žaidimas baigtas! Jūs užlipote ant minos.",
        memory_instructions: "Spustelėkite, kad apverstumėte kortas, raskite poras!",
        memory_win: "Jūs laimėjote!",
        timer_alert: "5 minutės baigėsi!"
    },
    ee: {
        tetris: "Tetris",
        "2048": "2048",
        minesweeper: "Miinijaht",
        memory: "Mälumäng",
        theme_light: "Hele",
        theme_dark: "Tume",
        difficulty_easy: "Lihtne",
        difficulty_medium: "Keskmine",
        difficulty_hard: "Raske",
        timer: "5 min",
        scores: "Tulemused",
        score: "Punktid",
        tetris_instructions: "←/→: Liiguta, ↓: Kiirenda, ↑: Pööra",
        "2048_instructions": "Nooled: Liiguta plaate",
        minesweeper_instructions: "Klõpsa avamiseks, väldi miine!",
        minesweeper_game_over: "Mäng läbi! Sa astusid miinile.",
        memory_instructions: "Klõpsa kaartide ümberpööramiseks, leia paarid!",
        memory_win: "Sa võitsid!",
        timer_alert: "5 minutit on möödas!"
    }
};

// Spēļu inicializācijas funkcijas
const games = {
    tetris: initTetris,
    "2048": init2048,
    minesweeper: initMinesweeper,
    memory: initMemory
};

// Rezultātu saglabāšana
function saveScore(game, score) {
    chrome.storage.local.get([game], (result) => {
        const highScore = result[game]?.highScore || 0;
        if (score > highScore) {
            chrome.storage.local.set({ [game]: { highScore: score } });
        }
    });
}

// Rezultātu attēlošana
function showScores(lang) {
    chrome.storage.local.get(null, (result) => {
        let scoresText = translations[lang].scores + ':\n';
        for (const game in games) {
            const highScore = result[game]?.highScore || 0;
            scoresText += `${translations[lang][game]}: ${highScore}\n`;
        }
        alert(scoresText);
    });
}

// Tulkojumu atjaunināšana
function updateTranslations(lang) {
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        element.textContent = translations[lang][key];
    });
    document.querySelectorAll('.game-btn').forEach(btn => {
        const game = btn.dataset.game;
        btn.textContent = translations[lang][game];
    });
}

// Inicializācija
let cleanup = null;
let lang = localStorage.getItem('language') || 'en';
document.addEventListener('DOMContentLoaded', () => {
    const gameContainer = document.getElementById('game-container');
    const instructionsContainer = document.getElementById('instructions');
    const languageSelect = document.getElementById('language');
    const themeSelect = document.getElementById('theme');
    const difficultySelect = document.getElementById('difficulty');
    const timerBtn = document.getElementById('timer-btn');
    const scoresBtn = document.getElementById('scores-btn');

    // Valodas maiņa
    languageSelect.addEventListener('change', (e) => {
        lang = e.target.value;
        localStorage.setItem('language', lang);
        updateTranslations(lang);
        if (cleanup) {
            cleanup();
            cleanup = null;
            gameContainer.innerHTML = '';
            instructionsContainer.textContent = '';
        }
    });

    // Tēmas maiņa
    themeSelect.addEventListener('change', (e) => {
        const theme = e.target.value;
        localStorage.setItem('theme', theme);
        document.body.classList.toggle('dark', theme === 'dark');
    });

    // Spēļu izvēle
    document.querySelectorAll('.game-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (cleanup) {
                cleanup();
                cleanup = null;
            }
            const game = btn.dataset.game;
            gameContainer.innerHTML = '';
            instructionsContainer.textContent = '';
            cleanup = games[game](gameContainer, instructionsContainer, lang);
        });
    });

    // Taimera funkcija
    timerBtn.addEventListener('click', () => {
        setTimeout(() => alert(translations[lang].timer_alert), 300000);
    });

    // Rezultātu tablo
    scoresBtn.addEventListener('click', () => showScores(lang));

    // Sākotnējā ielāde
    const savedTheme = localStorage.getItem('theme') || 'light';
    themeSelect.value = savedTheme;
    document.body.classList.toggle('dark', savedTheme === 'dark');

    lang = localStorage.getItem('language') || 'en';
    languageSelect.value = lang;
    updateTranslations(lang);
});